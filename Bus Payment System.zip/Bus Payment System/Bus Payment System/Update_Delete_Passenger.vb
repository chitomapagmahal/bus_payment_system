﻿Public Class Update_Delete_Passenger

    Dim image_location As String = ""
    Dim image_name As String = ""
    Dim prefix_image_name = Date.Now.ToString("MMddyyyy_hhmmsstt") '07012021105040pm_

    Private Sub Display()

        rs = New ADODB.Recordset
        rs.Open("SELECT * FROM `passengers`", cn, 1, 2)

        ListView1.Items.Clear()

        If Not rs.EOF Then

            Dim lvi As New ListViewItem

            While Not rs.EOF

                lvi = ListView1.Items.Add(rs.Fields("id").Value)
                lvi.SubItems.Add(rs.Fields("rfid").Value)
                lvi.SubItems.Add(rs.Fields("name").Value)
                lvi.SubItems.Add(rs.Fields("sex").Value)
                lvi.SubItems.Add("₱" & rs.Fields("current_credit_balance").Value)
                lvi.SubItems.Add(rs.Fields("image_location").Value)

                rs.MoveNext()

            End While

        End If

    End Sub

    Private Sub Update_Delete_Passenger_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Call Display()

    End Sub

    Private Sub Update_Delete_Passenger_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing

        Main.Show()

    End Sub

    Private Sub btn_search_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_search.Click

        If Not txt_search.Text = "" Then

            rs = New ADODB.Recordset
            rs.Open("SELECT * FROM `passengers` WHERE `rfid` LIKE '" & txt_search.Text & "%' ", cn, 1, 2)

            ListView1.Items.Clear()

            If Not rs.EOF Then

                Dim lvi As New ListViewItem

                While Not rs.EOF

                    lvi = ListView1.Items.Add(rs.Fields("id").Value)
                    lvi.SubItems.Add(rs.Fields("rfid").Value)
                    lvi.SubItems.Add(rs.Fields("name").Value)
                    lvi.SubItems.Add(rs.Fields("sex").Value)
                    lvi.SubItems.Add("₱" & rs.Fields("current_credit_balance").Value)
                    lvi.SubItems.Add(rs.Fields("image_location").Value)

                    rs.MoveNext()

                End While

            Else

                Call Display()

                MsgBox("No results found!", MsgBoxStyle.Exclamation, "No Results Found")

            End If

        End If

    End Sub

    Private Sub txt_search_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_search.TextChanged

        If txt_search.Text = "" Then

            Call Display()

        End If

    End Sub

    Private Sub ListView1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListView1.Click

        txt_rfid.Text = ListView1.SelectedItems(0).SubItems(1).Text
        txt_fname.Text = ListView1.SelectedItems(0).SubItems(2).Text
        txt_sex.Text = ListView1.SelectedItems(0).SubItems(3).Text
        PictureBox1.ImageLocation = "assets/user_images/" & ListView1.SelectedItems(0).SubItems(5).Text

        btn_clear.Enabled = True
        btn_save.Enabled = True
        btn_upload.Enabled = True

    End Sub

    Private Sub btn_clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_clear.Click

        DialogResult = MessageBox.Show("Are you sure you want to DELETE " & ListView1.SelectedItems(0).SubItems(2).Text & " from the Database?", "Delete Item", MessageBoxButtons.YesNo, MessageBoxIcon.Warning)

        If DialogResult = Windows.Forms.DialogResult.Yes Then

            rs = New ADODB.Recordset
            rs.Open("DELETE FROM `passengers` WHERE `id` = '" & ListView1.SelectedItems(0).Text & "'", cn, 1, 2)

            Call Display()

            txt_fname.Clear()
            txt_rfid.Clear()
            txt_sex.Text = Nothing

            btn_clear.Enabled = False
            btn_save.Enabled = False
            btn_upload.Enabled = False

            PictureBox1.ImageLocation = "assets/system_images/default_avatar.png"

            MsgBox("Passenger has been Deleted.", MsgBoxStyle.Information, "Deleted")

        End If

    End Sub

    Private Sub btn_save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_save.Click

        If txt_fname.Text = "" Then

            ErrorProvider1.SetError(txt_fname, "Fill out this Field")

        End If

        If txt_rfid.Text = "" Then

            ErrorProvider2.SetError(txt_rfid, "Fill out this Field")

        End If

        If txt_sex.Text = Nothing Then

            ErrorProvider3.SetError(txt_sex, "Fill out this Field")

        End If

        If Not txt_fname.Text = "" And Not txt_rfid.Text = "" And Not txt_sex.Text = "" Then

            rs = New ADODB.Recordset
            rs.Open("SELECT * FROM `passengers` WHERE `rfid` = '" & txt_rfid.Text & "'", cn, 1, 2)

            If Not rs.EOF And Not txt_rfid.Text = ListView1.SelectedItems(0).SubItems(1).Text Then

                ErrorProvider2.SetError(txt_rfid, "RFID Already Exists")

                MsgBox("RFID number already exists!", MsgBoxStyle.Exclamation, "RFID Already Exixts")

            Else

                DialogResult = MessageBox.Show("Do you want to save the following changes?", "Update Item", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

                If DialogResult = Windows.Forms.DialogResult.Yes Then

                    If Not image_location = "" Then

                        image_name = prefix_image_name & "_" & image_location.Substring(image_location.LastIndexOf("\") + 1) 'assets\user_files\dsadas.png

                        Try

                            My.Computer.FileSystem.CopyFile(image_location, "assets/user_images/" & image_name)

                        Catch ex As Exception

                            'Do nothing'

                        End Try

                    Else

                        image_name = ListView1.SelectedItems(0).SubItems(5).Text

                    End If

                    rs = New ADODB.Recordset
                    rs.Open("UPDATE `passengers` SET `rfid` = '" & txt_rfid.Text & "', `name` = '" & txt_fname.Text & "', `sex` = '" & txt_sex.Text & "', `image_location` = '" & image_name & "' WHERE `id` = '" & ListView1.SelectedItems(0).Text & "' ", cn, 1, 2)

                    Call Display()

                    txt_fname.Clear()
                    txt_rfid.Clear()
                    txt_sex.Text = Nothing

                    btn_clear.Enabled = False
                    btn_save.Enabled = False
                    btn_upload.Enabled = False

                    PictureBox1.ImageLocation = "assets/system_images/default_avatar.png"

                    MsgBox("Passenger Data is Updated!", MsgBoxStyle.Information, "Updated")

                End If

            End If

        End If

    End Sub

    Private Sub btn_upload_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_upload.Click

        OpenFileDialog1.Filter = "Picture Files (*)|*.bmp;*.gif;*.jpg;*.png"

        If OpenFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then

            image_location = OpenFileDialog1.FileName

            PictureBox1.Image = Image.FromFile(image_location)

        End If

    End Sub

    Private Sub txt_fname_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_fname.TextChanged

        ErrorProvider1.Dispose()

    End Sub

    Private Sub txt_rfid_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_rfid.TextChanged

        ErrorProvider2.Dispose()

    End Sub

    Private Sub txt_sex_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_sex.SelectedIndexChanged

        ErrorProvider3.Dispose()

    End Sub

    Private Sub txt_rfid_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txt_rfid.KeyPress

        If Asc(e.KeyChar) <> 8 Then

            If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then

                e.Handled = True

            End If

        End If

    End Sub
End Class