﻿Public Class View_Transactions

    Private Sub Display()

        rs = New ADODB.Recordset
        rs.Open("SELECT * FROM `transactions`", cn, 1, 2)

        If Not rs.EOF Then

            ListView1.Items.Clear()

            Dim lvi As New ListViewItem

            While Not rs.EOF

                lvi = ListView1.Items.Add(rs.Fields("id").Value)
                lvi.SubItems.Add(rs.Fields("date_time").Value)
                lvi.SubItems.Add(rs.Fields("passenger_name").Value)
                lvi.SubItems.Add(rs.Fields("from_point").Value)
                lvi.SubItems.Add(rs.Fields("to_point").Value)
                lvi.SubItems.Add(rs.Fields("passenger_type").Value)
                lvi.SubItems.Add("₱" & rs.Fields("fare").Value)

                rs.MoveNext()

            End While

        End If

    End Sub

    Private Sub View_Transactions_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing

        Main.Show()

    End Sub

    Private Sub View_Transactions_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Call Display()

    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged

        If Not TextBox1.Text = "" Then

            rs = New ADODB.Recordset
            rs.Open("SELECT * FROM `transactions` WHERE `passenger_name` LIKE '" & TextBox1.Text & "%' OR `date_time` LIKE '" & TextBox1.Text & "%' ", cn, 1, 2)

            If Not rs.EOF Then

                ListView1.Items.Clear()

                Dim lvi As New ListViewItem

                While Not rs.EOF

                    lvi = ListView1.Items.Add(rs.Fields("id").Value)
                    lvi.SubItems.Add(rs.Fields("date_time").Value)
                    lvi.SubItems.Add(rs.Fields("passenger_name").Value)
                    lvi.SubItems.Add(rs.Fields("from_point").Value)
                    lvi.SubItems.Add(rs.Fields("to_point").Value)
                    lvi.SubItems.Add(rs.Fields("passenger_type").Value)
                    lvi.SubItems.Add("₱" & rs.Fields("fare").Value)

                    rs.MoveNext()

                End While

            End If

        Else

            Call Display()

        End If

    End Sub
End Class