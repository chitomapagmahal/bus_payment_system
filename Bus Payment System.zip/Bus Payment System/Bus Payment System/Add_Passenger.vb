﻿Public Class Add_Passenger

    Dim image_location As String = ""
    Dim image_name As String = ""
    Dim prefix_image_name = Date.Now.ToString("MMddyyyy_hhmmsstt") '07012021105040pm_

    Private Sub btn_clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_clear.Click

        PictureBox1.ImageLocation = "assets/system_images/default_avatar.png"
        txt_fname.Clear()
        txt_rfid.Clear()
        txt_sex.Text = Nothing

    End Sub

    Private Sub btn_upload_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_upload.Click

        OpenFileDialog1.Filter = "Picture Files (*)|*.bmp;*.gif;*.jpg;*.png"

        If OpenFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then

            image_location = OpenFileDialog1.FileName

            PictureBox1.Image = Image.FromFile(image_location)

        End If

    End Sub

    Private Sub btn_save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_save.Click

        If txt_fname.Text = "" Then

            ErrorProvider1.SetError(txt_fname, "Fill out this Field")

        End If

        If txt_rfid.Text = "" Then

            ErrorProvider2.SetError(txt_rfid, "Fill out this Field")

        End If

        If txt_sex.Text = Nothing Then

            ErrorProvider3.SetError(txt_sex, "Fill out this Field")

        End If

        If Not txt_fname.Text = "" And Not txt_rfid.Text = "" And Not txt_sex.Text = "" Then

            rs = New ADODB.Recordset
            rs.Open("SELECT * FROM `passengers` WHERE `rfid` = '" & txt_rfid.Text & "'", cn, 1, 2)

            If Not rs.EOF Then

                ErrorProvider2.SetError(txt_rfid, "RFID Already Exists")

                MsgBox("RFID number already exists!", MsgBoxStyle.Exclamation, "RFID Already Exixts")

            Else

                If Not image_location = "" Then

                    image_name = prefix_image_name & "_" & image_location.Substring(image_location.LastIndexOf("\") + 1) 'assets\user_files\dsadas.png

                    My.Computer.FileSystem.CopyFile(image_location, "assets/user_images/" & image_name)

                Else

                    image_name = "default_avatar.png"

                End If

                rs = New ADODB.Recordset
                rs.Open("INSERT INTO `passengers` (`rfid`, `name`, `sex`, `image_location`) VALUES ('" & txt_rfid.Text & "', '" & txt_fname.Text & "', '" & txt_sex.Text & "', '" & image_name & "') ", cn, 1, 2)

                btn_clear.PerformClick()

                MsgBox("Passenger Data Added to Database!", MsgBoxStyle.Information, "Added")

            End If

        End If

    End Sub

    Private Sub txt_fname_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_fname.TextChanged

        ErrorProvider1.Dispose()

    End Sub

    Private Sub txt_rfid_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_rfid.TextChanged

        ErrorProvider2.Dispose()

    End Sub

    Private Sub txt_sex_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_sex.SelectedIndexChanged

        ErrorProvider3.Dispose()

    End Sub

    Private Sub Add_Passenger_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing

        Main.Show()

    End Sub

    Private Sub txt_rfid_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txt_rfid.KeyPress

        If Asc(e.KeyChar) <> 8 Then

            If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then

                e.Handled = True

            End If

        End If

    End Sub
End Class