﻿Public Class Topup

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        If txt_rfid.Text = "" Then

            ErrorProvider1.SetError(txt_rfid, "Fill out this field")

        End If

        If txt_amount.Text = "" Then

            ErrorProvider2.SetError(txt_amount, "Fill out this field")

        End If

        If Not txt_rfid.Text = "" And Not txt_amount.Text = "" Then

            If Not IsNumeric(txt_amount.Text) Then

                MsgBox("Invalid Amount!", MsgBoxStyle.Critical, "Invalid Amount")

                ErrorProvider2.SetError(txt_amount, "Invalid Input")

            Else

                rs = New ADODB.Recordset
                rs.Open("SELECT * FROM `passengers` WHERE `rfid` = '" & txt_rfid.Text & "' LIMIT 1 ", cn, 1, 2)

                If Not rs.EOF Then

                    Dim name As String = rs.Fields("name").Value

                    Dim amount As Double = Double.Parse(rs.Fields("current_credit_balance").Value)
                    Dim current_amount As String
                    Dim temp_amount As String

                    amount = amount + Double.Parse(txt_amount.Text)

                    If Not Str(amount).Contains(".") Then

                        current_amount = Str(amount) & ".00"

                    Else

                        current_amount = amount

                    End If

                    If Not txt_amount.Text.Contains(".") Then

                        temp_amount = txt_amount.Text & ".00"

                    Else

                        temp_amount = txt_amount.Text

                    End If

                    rs = New ADODB.Recordset
                    rs.Open("UPDATE `passengers` SET `current_credit_balance` = '" & current_amount & "' WHERE `rfid` = '" & txt_rfid.Text & "' ", cn, 1, 2)

                    txt_amount.Clear()
                    txt_rfid.Clear()

                    MsgBox("₱" & temp_amount & " has been loaded to " & name & ".", MsgBoxStyle.Information, "Topup Success")

                Else

                    ErrorProvider1.SetError(txt_rfid, "Invalid RFID")

                    MsgBox("RFID Number is not valid!", MsgBoxStyle.Critical, "Invalid RFID")

                End If

            End If

        End If

    End Sub

    Private Sub txt_rfid_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_rfid.TextChanged

        ErrorProvider1.Dispose()

    End Sub

    Private Sub txt_amount_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_amount.TextChanged

        ErrorProvider2.Dispose()

    End Sub

    Private Sub txt_rfid_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txt_rfid.KeyPress

        If Asc(e.KeyChar) <> 8 Then

            If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then

                e.Handled = True

            End If

        End If

    End Sub

    Private Sub Topup_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing

        Main.Show()

    End Sub
End Class