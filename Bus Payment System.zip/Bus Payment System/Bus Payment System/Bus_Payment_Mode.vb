﻿Public Class Bus_Payment_Mode

    Dim fare As Double

    Private Sub txt_rfid_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txt_rfid.KeyPress

        If Asc(e.KeyChar) <> 8 Then

            If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then

                e.Handled = True

            End If

        End If

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        If txt_rfid.Text = "" Then

            ErrorProvider1.SetError(txt_rfid, "Fill out this field")

        End If

        If txt_from.Text = Nothing Then

            ErrorProvider2.SetError(txt_from, "Select an item")

        End If

        If txt_to.Text = Nothing Then

            ErrorProvider3.SetError(txt_to, "Select an item")

        End If

        If txt_discount.Text = Nothing Then

            ErrorProvider4.SetError(txt_discount, "Select an Item")

        End If

        If Not txt_rfid.Text = "" And Not txt_from.Text = Nothing And Not txt_to.Text = Nothing And Not txt_discount.Text = Nothing Then

            rs = New ADODB.Recordset
            rs.Open("SELECT * FROM `passengers` WHERE `rfid` = '" & txt_rfid.Text & "' ", cn, 1, 2)

            If rs.EOF Then

                MsgBox("Invalid RFID Number!", MsgBoxStyle.Critical, "Invalid RFID")

                ErrorProvider1.SetError(txt_rfid, "Invalid RFID")

            Else

                current_balance = Double.Parse(rs.Fields("current_credit_balance").Value)
                current_fee = Double.Parse(0.12 * Double.Parse(txt_total.Text)) + Double.Parse(txt_total.Text)
                rfid = rs.Fields("rfid").Value
                passenger_name = rs.Fields("name").Value

                If current_balance < current_fee Then

                    MsgBox("You do not have enough balance!", MsgBoxStyle.Critical, "Insuficient Balance")

                Else

                    Dim str_original_fare As String
                    Dim str_discount As String = Str(discount * Double.Parse(original_fare))
                    Dim str_total As String = Str(Double.Parse(original_fare - Double.Parse(discount * Double.Parse(original_fare))))

                    If Not Str(original_fare).Contains(".") Then

                        str_original_fare = Str(original_fare) & ".00"

                    Else

                        str_original_fare = Str(original_fare)

                    End If

                    If Not str_discount.Contains(".") Then

                        str_discount = str_discount & ".00"

                    Else

                        str_discount = str_discount

                    End If

                    If Not str_total.Contains(".") Then

                        str_total = str_total & ".00"

                    Else

                        str_total = str_total

                    End If

                    With Receipt

                        .lbl_date.Text = Date.Now.ToString("MM/dd/yyyy")
                        .lbl_time.Text = Date.Now.ToString("hh:mm tt")
                        .lbl_from.Text = txt_from.Text
                        .lbl_to.Text = txt_to.Text
                        .lbl_driver.Text = Main.status_admin_name.Text
                        .lbl_plate_number.Text = plate_number
                        .lbl_fare.Text = "₱" & str_original_fare
                        .lbl_tax.Text = "₱" & str_discount
                        .lbl_total.Text = "₱" & str_total

                        .ShowDialog()

                    End With

                End If

            End If

        End If

    End Sub

    Private Sub txt_rfid_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_rfid.TextChanged

        ErrorProvider1.Dispose()

    End Sub

    Private Sub txt_from_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_from.SelectedIndexChanged

        ErrorProvider2.Dispose()

        If txt_from.Text = "Philcoa" Then

            txt_to.Items.Clear()

            txt_to.Items.Add("New Era")
            txt_to.Items.Add("Tandang Sora")
            txt_to.Items.Add("Ever")
            txt_to.Items.Add("Litex")

        Else

            txt_to.Items.Clear()

            txt_to.Items.Add("Ever")
            txt_to.Items.Add("Tandang Sora")
            txt_to.Items.Add("New Era")
            txt_to.Items.Add("Philcoa")

        End If

        If Not txt_to.Text = Nothing Then

            If txt_from.Text = "Philcoa" And txt_to.Text = "New Era" Then

                original_fare = 10

                txt_total.Text = original_fare - (original_fare * discount)

            End If

            If txt_from.Text = "Philcoa" And txt_to.Text = "Tandang Sora" Then

                original_fare = 15

                txt_total.Text = original_fare - (original_fare * discount)

            End If

            If txt_from.Text = "Philcoa" And txt_to.Text = "Ever" Then

                original_fare = 20

                txt_total.Text = original_fare - (original_fare * discount)

            End If

            If txt_from.Text = "Philcoa" And txt_to.Text = "Litex" Then

                original_fare = 25

                txt_total.Text = original_fare - (original_fare * discount)

            End If

            If txt_from.Text = "Litex" And txt_to.Text = "Ever" Then

                original_fare = 10

                txt_total.Text = original_fare - (original_fare * discount)

            End If

            If txt_from.Text = "Litex" And txt_to.Text = "Tandang Sora" Then

                original_fare = 15

                txt_total.Text = original_fare - (original_fare * discount)

            End If

            If txt_from.Text = "Litex" And txt_to.Text = "New Era" Then

                original_fare = 20

                txt_total.Text = original_fare - (original_fare * discount)

            End If

            If txt_from.Text = "Litex" And txt_to.Text = "Philcoa" Then

                original_fare = 25

                txt_total.Text = original_fare - (original_fare * discount)

            End If

        End If

    End Sub

    Private Sub txt_to_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_to.SelectedIndexChanged

        ErrorProvider3.Dispose()

        If Not txt_from.Text = Nothing Then

            If txt_from.Text = "Philcoa" And txt_to.Text = "New Era" Then

                original_fare = 10

                txt_total.Text = original_fare - (original_fare * discount)

            End If

            If txt_from.Text = "Philcoa" And txt_to.Text = "Tandang Sora" Then

                original_fare = 15

                txt_total.Text = original_fare - (original_fare * discount)

            End If

            If txt_from.Text = "Philcoa" And txt_to.Text = "Ever" Then

                original_fare = 20

                txt_total.Text = original_fare - (original_fare * discount)

            End If

            If txt_from.Text = "Philcoa" And txt_to.Text = "Litex" Then

                original_fare = 25

                txt_total.Text = original_fare - (original_fare * discount)

            End If

            If txt_from.Text = "Litex" And txt_to.Text = "Ever" Then

                original_fare = 10

                txt_total.Text = original_fare - (original_fare * discount)

            End If

            If txt_from.Text = "Litex" And txt_to.Text = "Tandang Sora" Then

                original_fare = 15

                txt_total.Text = original_fare - (original_fare * discount)

            End If

            If txt_from.Text = "Litex" And txt_to.Text = "New Era" Then

                original_fare = 20

                txt_total.Text = original_fare - (original_fare * discount)

            End If

            If txt_from.Text = "Litex" And txt_to.Text = "Philcoa" Then

                original_fare = 25

                txt_total.Text = original_fare - (original_fare * discount)

            End If

        End If

    End Sub

    Private Sub Bus_Payment_Mode_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing

        Main.Show()

    End Sub

    Private Sub txt_discount_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_discount.SelectedIndexChanged

        ErrorProvider4.Dispose()

        If txt_discount.SelectedItem = "Regular" Then

            discount = 0

            txt_total.Text = original_fare

        Else

            discount = 0.2

            txt_total.Text = original_fare - (original_fare * discount)

        End If

    End Sub

End Class