﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Receipt
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Receipt))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lbl_date = New System.Windows.Forms.Label()
        Me.lbl_time = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lbl_from = New System.Windows.Forms.TextBox()
        Me.lbl_to = New System.Windows.Forms.TextBox()
        Me.lbl_driver = New System.Windows.Forms.TextBox()
        Me.lbl_plate_number = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.lbl_fare = New System.Windows.Forms.TextBox()
        Me.lbl_tax = New System.Windows.Forms.TextBox()
        Me.lbl_total = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.White
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(203, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(183, 29)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "BUS RECEIPT"
        '
        'lbl_date
        '
        Me.lbl_date.AutoSize = True
        Me.lbl_date.BackColor = System.Drawing.Color.Transparent
        Me.lbl_date.Font = New System.Drawing.Font("Microsoft Tai Le", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_date.ForeColor = System.Drawing.Color.Black
        Me.lbl_date.Location = New System.Drawing.Point(62, 114)
        Me.lbl_date.Name = "lbl_date"
        Me.lbl_date.Size = New System.Drawing.Size(101, 19)
        Me.lbl_date.TabIndex = 1
        Me.lbl_date.Text = "MM/dd/yyyy"
        '
        'lbl_time
        '
        Me.lbl_time.AutoSize = True
        Me.lbl_time.BackColor = System.Drawing.Color.Transparent
        Me.lbl_time.Font = New System.Drawing.Font("Microsoft Tai Le", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_time.ForeColor = System.Drawing.Color.Black
        Me.lbl_time.Location = New System.Drawing.Point(478, 114)
        Me.lbl_time.Name = "lbl_time"
        Me.lbl_time.Size = New System.Drawing.Size(75, 19)
        Me.lbl_time.TabIndex = 2
        Me.lbl_time.Text = "hh:mm tt"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.White
        Me.Label2.Font = New System.Drawing.Font("Microsoft Tai Le", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(12, 276)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(55, 19)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Plate #"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.White
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(56, 355)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(469, 20)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "Press ENTER to ""Confirm Transaction or ESC to ""Cancel"""
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.White
        Me.Label4.Font = New System.Drawing.Font("Microsoft Tai Le", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(407, 276)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(67, 19)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "Discount"
        '
        'lbl_from
        '
        Me.lbl_from.BackColor = System.Drawing.Color.White
        Me.lbl_from.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lbl_from.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_from.Location = New System.Drawing.Point(157, 153)
        Me.lbl_from.Name = "lbl_from"
        Me.lbl_from.ReadOnly = True
        Me.lbl_from.Size = New System.Drawing.Size(402, 15)
        Me.lbl_from.TabIndex = 13
        Me.lbl_from.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lbl_to
        '
        Me.lbl_to.BackColor = System.Drawing.Color.White
        Me.lbl_to.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lbl_to.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_to.Location = New System.Drawing.Point(157, 195)
        Me.lbl_to.Name = "lbl_to"
        Me.lbl_to.ReadOnly = True
        Me.lbl_to.Size = New System.Drawing.Size(402, 15)
        Me.lbl_to.TabIndex = 14
        Me.lbl_to.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lbl_driver
        '
        Me.lbl_driver.BackColor = System.Drawing.Color.White
        Me.lbl_driver.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lbl_driver.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_driver.Location = New System.Drawing.Point(70, 236)
        Me.lbl_driver.Name = "lbl_driver"
        Me.lbl_driver.ReadOnly = True
        Me.lbl_driver.Size = New System.Drawing.Size(214, 15)
        Me.lbl_driver.TabIndex = 15
        Me.lbl_driver.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lbl_plate_number
        '
        Me.lbl_plate_number.BackColor = System.Drawing.Color.White
        Me.lbl_plate_number.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lbl_plate_number.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_plate_number.Location = New System.Drawing.Point(70, 277)
        Me.lbl_plate_number.Name = "lbl_plate_number"
        Me.lbl_plate_number.ReadOnly = True
        Me.lbl_plate_number.Size = New System.Drawing.Size(214, 15)
        Me.lbl_plate_number.TabIndex = 16
        Me.lbl_plate_number.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox5
        '
        Me.TextBox5.BackColor = System.Drawing.Color.White
        Me.TextBox5.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox5.Location = New System.Drawing.Point(70, 318)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.ReadOnly = True
        Me.TextBox5.Size = New System.Drawing.Size(214, 15)
        Me.TextBox5.TabIndex = 17
        Me.TextBox5.Text = "None"
        Me.TextBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lbl_fare
        '
        Me.lbl_fare.BackColor = System.Drawing.Color.White
        Me.lbl_fare.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lbl_fare.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_fare.Location = New System.Drawing.Point(473, 236)
        Me.lbl_fare.Name = "lbl_fare"
        Me.lbl_fare.ReadOnly = True
        Me.lbl_fare.Size = New System.Drawing.Size(86, 15)
        Me.lbl_fare.TabIndex = 18
        Me.lbl_fare.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lbl_tax
        '
        Me.lbl_tax.BackColor = System.Drawing.Color.White
        Me.lbl_tax.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lbl_tax.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_tax.Location = New System.Drawing.Point(473, 277)
        Me.lbl_tax.Name = "lbl_tax"
        Me.lbl_tax.ReadOnly = True
        Me.lbl_tax.Size = New System.Drawing.Size(86, 15)
        Me.lbl_tax.TabIndex = 19
        Me.lbl_tax.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lbl_total
        '
        Me.lbl_total.BackColor = System.Drawing.Color.White
        Me.lbl_total.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.lbl_total.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_total.Location = New System.Drawing.Point(473, 318)
        Me.lbl_total.Name = "lbl_total"
        Me.lbl_total.ReadOnly = True
        Me.lbl_total.Size = New System.Drawing.Size(86, 15)
        Me.lbl_total.TabIndex = 20
        Me.lbl_total.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Receipt
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(580, 386)
        Me.Controls.Add(Me.lbl_total)
        Me.Controls.Add(Me.lbl_tax)
        Me.Controls.Add(Me.lbl_fare)
        Me.Controls.Add(Me.TextBox5)
        Me.Controls.Add(Me.lbl_plate_number)
        Me.Controls.Add(Me.lbl_driver)
        Me.Controls.Add(Me.lbl_to)
        Me.Controls.Add(Me.lbl_from)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lbl_time)
        Me.Controls.Add(Me.lbl_date)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Receipt"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lbl_date As System.Windows.Forms.Label
    Friend WithEvents lbl_time As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents lbl_from As System.Windows.Forms.TextBox
    Friend WithEvents lbl_to As System.Windows.Forms.TextBox
    Friend WithEvents lbl_driver As System.Windows.Forms.TextBox
    Friend WithEvents lbl_plate_number As System.Windows.Forms.TextBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents lbl_fare As System.Windows.Forms.TextBox
    Friend WithEvents lbl_tax As System.Windows.Forms.TextBox
    Friend WithEvents lbl_total As System.Windows.Forms.TextBox
End Class
