﻿Public Class Receipt

    Private Sub Receipt_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown

        If e.KeyCode = Keys.Escape Then

            Me.Close()

        End If

        If e.KeyCode = Keys.Enter Then

            current_balance = current_balance - current_fee

            rs = New ADODB.Recordset
            rs.Open("UPDATE `passengers` SET `current_credit_balance` = '" & current_balance & "' WHERE `rfid` = '" & rfid & "'", cn, 1, 2)

            Me.Close()

            With Bus_Payment_Mode

                .txt_from.Text = Nothing
                .txt_to.Items.Clear()
                .txt_rfid.Clear()
                .txt_total.Clear()

            End With

            MsgBox("Transaction Successful. Enjoy your ride.", MsgBoxStyle.Information, "Transaction Successful")

        End If

    End Sub

    Private Sub lbl_from_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TextBox5.KeyDown, lbl_total.KeyDown, lbl_to.KeyDown, lbl_tax.KeyDown, lbl_plate_number.KeyDown, lbl_from.KeyDown, lbl_fare.KeyDown, lbl_driver.KeyDown

        If e.KeyCode = Keys.Escape Then

            Me.Close()

        End If

        If e.KeyCode = Keys.Enter Then

            current_balance = current_balance - current_fee

            Dim str_balance As String

            If Not Str(current_balance).Contains(".") Then

                str_balance = Str(current_balance) & ".00"

            Else

                str_balance = Str(current_balance)

            End If

            rs = New ADODB.Recordset
            rs.Open("UPDATE `passengers` SET `current_credit_balance` = '" & str_balance & "' WHERE `rfid` = '" & rfid & "'", cn, 1, 2)

            rs = New ADODB.Recordset
            rs.Open("INSERT INTO `transactions` (`passenger_name`, `from_point`, `to_point`, `passenger_type`, `fare`) VALUES ('" & passenger_name & "', '" & lbl_from.Text & "', '" & lbl_to.Text & "', '" & Bus_Payment_Mode.txt_discount.Text & "', '" & lbl_total.Text.Remove(0, 1) & "')", cn, 1, 2)

            Me.Close()

            With Bus_Payment_Mode

                .txt_from.Text = Nothing
                .txt_discount.Text = Nothing
                .txt_to.Items.Clear()
                .txt_rfid.Clear()
                .txt_total.Clear()

            End With

            discount = 0

            MsgBox("Transaction Successful. Enjoy your ride.", MsgBoxStyle.Information, "Transaction Successful")

        End If

    End Sub

End Class