﻿Module Module1

    Public cn As New ADODB.Connection
    Public rs As New ADODB.Recordset

    Public plate_number As String
    Public current_balance As Double
    Public current_fee As Double
    Public rfid As String
    Public original_fare As Double
    Public discount As Double = 0
    Public passenger_name As String

    Public Sub DATABASE_CONNECTION()

        cn = New ADODB.Connection
        cn.ConnectionString = "Driver=MySQL ODBC 3.51 Driver; Server=localhost; User=root; Database=bus_payment_system"
        cn.Open()

    End Sub


End Module
