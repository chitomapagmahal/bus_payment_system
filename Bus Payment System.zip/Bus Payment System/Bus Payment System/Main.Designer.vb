﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Main))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lbl_desc_edit_pass = New System.Windows.Forms.Label()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.status_admin_name = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel4 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.status_date = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel6 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel7 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.status_time = New System.Windows.Forms.ToolStripStatusLabel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.pnl_add_passenger = New System.Windows.Forms.Panel()
        Me.pnl_edit_remove_passenger = New System.Windows.Forms.Panel()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.pnl_topup = New System.Windows.Forms.Panel()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.pnl_logout = New System.Windows.Forms.Panel()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.pnl_bus_payment_mode = New System.Windows.Forms.Panel()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.pnl_view_trans = New System.Windows.Forms.Panel()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.lbl_desc_add_pass = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.lbl_desc_logout = New System.Windows.Forms.Label()
        Me.lbl_desc_bus_payment_mode = New System.Windows.Forms.Label()
        Me.lbl_desc_view_trans = New System.Windows.Forms.Label()
        Me.lbl_desc_topup = New System.Windows.Forms.Label()
        Me.lbl_default = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnl_add_passenger.SuspendLayout()
        Me.pnl_edit_remove_passenger.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnl_topup.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnl_logout.SuspendLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnl_bus_payment_mode.SuspendLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnl_view_trans.SuspendLayout()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(14, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(234, 152)
        Me.Panel1.TabIndex = 0
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Modern No. 20", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(108, 92)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(110, 34)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "System"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Modern No. 20", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(43, 58)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(136, 34)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Payment"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Modern No. 20", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(15, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(69, 34)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Bus"
        '
        'lbl_desc_edit_pass
        '
        Me.lbl_desc_edit_pass.AutoSize = True
        Me.lbl_desc_edit_pass.Font = New System.Drawing.Font("OCR A Extended", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_desc_edit_pass.ForeColor = System.Drawing.Color.White
        Me.lbl_desc_edit_pass.Location = New System.Drawing.Point(7, 58)
        Me.lbl_desc_edit_pass.Name = "lbl_desc_edit_pass"
        Me.lbl_desc_edit_pass.Size = New System.Drawing.Size(218, 34)
        Me.lbl_desc_edit_pass.TabIndex = 4
        Me.lbl_desc_edit_pass.Text = "Edit or Remove" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Registered Passengers"
        Me.lbl_desc_edit_pass.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lbl_desc_edit_pass.Visible = False
        '
        'StatusStrip1
        '
        Me.StatusStrip1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.status_admin_name, Me.ToolStripStatusLabel3, Me.ToolStripStatusLabel4, Me.status_date, Me.ToolStripStatusLabel6, Me.ToolStripStatusLabel7, Me.status_time})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 335)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(734, 22)
        Me.StatusStrip1.TabIndex = 4
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(82, 17)
        Me.ToolStripStatusLabel1.Text = "Admin Name:"
        '
        'status_admin_name
        '
        Me.status_admin_name.BackColor = System.Drawing.Color.WhiteSmoke
        Me.status_admin_name.Name = "status_admin_name"
        Me.status_admin_name.Size = New System.Drawing.Size(80, 17)
        Me.status_admin_name.Text = "Administrator"
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(37, 17)
        Me.ToolStripStatusLabel3.Text = "          "
        '
        'ToolStripStatusLabel4
        '
        Me.ToolStripStatusLabel4.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ToolStripStatusLabel4.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel4.Name = "ToolStripStatusLabel4"
        Me.ToolStripStatusLabel4.Size = New System.Drawing.Size(83, 17)
        Me.ToolStripStatusLabel4.Text = "Current Date:"
        '
        'status_date
        '
        Me.status_date.BackColor = System.Drawing.Color.WhiteSmoke
        Me.status_date.Name = "status_date"
        Me.status_date.Size = New System.Drawing.Size(77, 17)
        Me.status_date.Text = "MM/dd/yyyy"
        '
        'ToolStripStatusLabel6
        '
        Me.ToolStripStatusLabel6.Name = "ToolStripStatusLabel6"
        Me.ToolStripStatusLabel6.Size = New System.Drawing.Size(37, 17)
        Me.ToolStripStatusLabel6.Text = "          "
        '
        'ToolStripStatusLabel7
        '
        Me.ToolStripStatusLabel7.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ToolStripStatusLabel7.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel7.Name = "ToolStripStatusLabel7"
        Me.ToolStripStatusLabel7.Size = New System.Drawing.Size(84, 17)
        Me.ToolStripStatusLabel7.Text = "Current Time:"
        '
        'status_time
        '
        Me.status_time.BackColor = System.Drawing.Color.WhiteSmoke
        Me.status_time.Name = "status_time"
        Me.status_time.Size = New System.Drawing.Size(70, 17)
        Me.status_time.Text = "hh:mm:ss tt"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(7, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(138, 122)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 5
        Me.PictureBox1.TabStop = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(19, 128)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(115, 16)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "Add Passenger"
        '
        'pnl_add_passenger
        '
        Me.pnl_add_passenger.BackColor = System.Drawing.Color.White
        Me.pnl_add_passenger.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnl_add_passenger.Controls.Add(Me.PictureBox1)
        Me.pnl_add_passenger.Controls.Add(Me.Label6)
        Me.pnl_add_passenger.Cursor = System.Windows.Forms.Cursors.Hand
        Me.pnl_add_passenger.Location = New System.Drawing.Point(254, 12)
        Me.pnl_add_passenger.Name = "pnl_add_passenger"
        Me.pnl_add_passenger.Size = New System.Drawing.Size(154, 152)
        Me.pnl_add_passenger.TabIndex = 7
        '
        'pnl_edit_remove_passenger
        '
        Me.pnl_edit_remove_passenger.BackColor = System.Drawing.Color.White
        Me.pnl_edit_remove_passenger.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnl_edit_remove_passenger.Controls.Add(Me.PictureBox2)
        Me.pnl_edit_remove_passenger.Controls.Add(Me.Label7)
        Me.pnl_edit_remove_passenger.Cursor = System.Windows.Forms.Cursors.Hand
        Me.pnl_edit_remove_passenger.Location = New System.Drawing.Point(411, 12)
        Me.pnl_edit_remove_passenger.Name = "pnl_edit_remove_passenger"
        Me.pnl_edit_remove_passenger.Size = New System.Drawing.Size(154, 152)
        Me.pnl_edit_remove_passenger.TabIndex = 8
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(7, 3)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(138, 122)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 5
        Me.PictureBox2.TabStop = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(4, 130)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(144, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Edit/Remove Passenger"
        '
        'pnl_topup
        '
        Me.pnl_topup.BackColor = System.Drawing.Color.White
        Me.pnl_topup.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnl_topup.Controls.Add(Me.PictureBox3)
        Me.pnl_topup.Controls.Add(Me.Label8)
        Me.pnl_topup.Cursor = System.Windows.Forms.Cursors.Hand
        Me.pnl_topup.Location = New System.Drawing.Point(568, 12)
        Me.pnl_topup.Name = "pnl_topup"
        Me.pnl_topup.Size = New System.Drawing.Size(154, 152)
        Me.pnl_topup.TabIndex = 9
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(7, 3)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(138, 122)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 5
        Me.PictureBox3.TabStop = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(23, 128)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(106, 16)
        Me.Label8.TabIndex = 6
        Me.Label8.Text = "Topup Credits"
        '
        'pnl_logout
        '
        Me.pnl_logout.BackColor = System.Drawing.Color.White
        Me.pnl_logout.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnl_logout.Controls.Add(Me.PictureBox4)
        Me.pnl_logout.Controls.Add(Me.Label9)
        Me.pnl_logout.Cursor = System.Windows.Forms.Cursors.Hand
        Me.pnl_logout.Location = New System.Drawing.Point(568, 170)
        Me.pnl_logout.Name = "pnl_logout"
        Me.pnl_logout.Size = New System.Drawing.Size(154, 152)
        Me.pnl_logout.TabIndex = 12
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = CType(resources.GetObject("PictureBox4.Image"), System.Drawing.Image)
        Me.PictureBox4.Location = New System.Drawing.Point(7, 3)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(138, 122)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox4.TabIndex = 5
        Me.PictureBox4.TabStop = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(25, 128)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(102, 16)
        Me.Label9.TabIndex = 6
        Me.Label9.Text = "Logout Admin"
        '
        'pnl_bus_payment_mode
        '
        Me.pnl_bus_payment_mode.BackColor = System.Drawing.Color.White
        Me.pnl_bus_payment_mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnl_bus_payment_mode.Controls.Add(Me.PictureBox5)
        Me.pnl_bus_payment_mode.Controls.Add(Me.Label10)
        Me.pnl_bus_payment_mode.Cursor = System.Windows.Forms.Cursors.Hand
        Me.pnl_bus_payment_mode.Location = New System.Drawing.Point(254, 170)
        Me.pnl_bus_payment_mode.Name = "pnl_bus_payment_mode"
        Me.pnl_bus_payment_mode.Size = New System.Drawing.Size(154, 152)
        Me.pnl_bus_payment_mode.TabIndex = 11
        '
        'PictureBox5
        '
        Me.PictureBox5.Image = CType(resources.GetObject("PictureBox5.Image"), System.Drawing.Image)
        Me.PictureBox5.Location = New System.Drawing.Point(7, 3)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(138, 122)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox5.TabIndex = 5
        Me.PictureBox5.TabStop = False
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(6, 128)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(141, 16)
        Me.Label10.TabIndex = 6
        Me.Label10.Text = "Bus Payment Mode"
        '
        'pnl_view_trans
        '
        Me.pnl_view_trans.BackColor = System.Drawing.Color.White
        Me.pnl_view_trans.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnl_view_trans.Controls.Add(Me.PictureBox6)
        Me.pnl_view_trans.Controls.Add(Me.Label11)
        Me.pnl_view_trans.Cursor = System.Windows.Forms.Cursors.Hand
        Me.pnl_view_trans.Location = New System.Drawing.Point(411, 171)
        Me.pnl_view_trans.Name = "pnl_view_trans"
        Me.pnl_view_trans.Size = New System.Drawing.Size(154, 152)
        Me.pnl_view_trans.TabIndex = 10
        '
        'PictureBox6
        '
        Me.PictureBox6.Image = CType(resources.GetObject("PictureBox6.Image"), System.Drawing.Image)
        Me.PictureBox6.Location = New System.Drawing.Point(7, 3)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(138, 122)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox6.TabIndex = 5
        Me.PictureBox6.TabStop = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(9, 128)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(135, 16)
        Me.Label11.TabIndex = 6
        Me.Label11.Text = "View Transactions"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'lbl_desc_add_pass
        '
        Me.lbl_desc_add_pass.AutoSize = True
        Me.lbl_desc_add_pass.Font = New System.Drawing.Font("OCR A Extended", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_desc_add_pass.ForeColor = System.Drawing.Color.White
        Me.lbl_desc_add_pass.Location = New System.Drawing.Point(17, 67)
        Me.lbl_desc_add_pass.Name = "lbl_desc_add_pass"
        Me.lbl_desc_add_pass.Size = New System.Drawing.Size(198, 17)
        Me.lbl_desc_add_pass.TabIndex = 13
        Me.lbl_desc_add_pass.Text = "Register Passengers"
        Me.lbl_desc_add_pass.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lbl_desc_add_pass.Visible = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(56, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(120, 25)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Description"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Transparent
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.lbl_desc_logout)
        Me.Panel2.Controls.Add(Me.lbl_desc_bus_payment_mode)
        Me.Panel2.Controls.Add(Me.lbl_desc_view_trans)
        Me.Panel2.Controls.Add(Me.lbl_desc_topup)
        Me.Panel2.Controls.Add(Me.lbl_default)
        Me.Panel2.Controls.Add(Me.lbl_desc_add_pass)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.lbl_desc_edit_pass)
        Me.Panel2.Location = New System.Drawing.Point(14, 170)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(234, 152)
        Me.Panel2.TabIndex = 3
        '
        'lbl_desc_logout
        '
        Me.lbl_desc_logout.AutoSize = True
        Me.lbl_desc_logout.Font = New System.Drawing.Font("OCR A Extended", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_desc_logout.ForeColor = System.Drawing.Color.White
        Me.lbl_desc_logout.Location = New System.Drawing.Point(12, 67)
        Me.lbl_desc_logout.Name = "lbl_desc_logout"
        Me.lbl_desc_logout.Size = New System.Drawing.Size(208, 17)
        Me.lbl_desc_logout.TabIndex = 18
        Me.lbl_desc_logout.Text = "Administrator Logout"
        Me.lbl_desc_logout.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lbl_desc_logout.Visible = False
        '
        'lbl_desc_bus_payment_mode
        '
        Me.lbl_desc_bus_payment_mode.AutoSize = True
        Me.lbl_desc_bus_payment_mode.Font = New System.Drawing.Font("OCR A Extended", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_desc_bus_payment_mode.ForeColor = System.Drawing.Color.White
        Me.lbl_desc_bus_payment_mode.Location = New System.Drawing.Point(2, 50)
        Me.lbl_desc_bus_payment_mode.Name = "lbl_desc_bus_payment_mode"
        Me.lbl_desc_bus_payment_mode.Size = New System.Drawing.Size(228, 51)
        Me.lbl_desc_bus_payment_mode.TabIndex = 17
        Me.lbl_desc_bus_payment_mode.Text = "Collects Payments from" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Passengers using RFID" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Cards"
        Me.lbl_desc_bus_payment_mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lbl_desc_bus_payment_mode.Visible = False
        '
        'lbl_desc_view_trans
        '
        Me.lbl_desc_view_trans.AutoSize = True
        Me.lbl_desc_view_trans.Font = New System.Drawing.Font("OCR A Extended", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_desc_view_trans.ForeColor = System.Drawing.Color.White
        Me.lbl_desc_view_trans.Location = New System.Drawing.Point(7, 58)
        Me.lbl_desc_view_trans.Name = "lbl_desc_view_trans"
        Me.lbl_desc_view_trans.Size = New System.Drawing.Size(218, 34)
        Me.lbl_desc_view_trans.TabIndex = 16
        Me.lbl_desc_view_trans.Text = "View all Transactions" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "made from Bus Payment"
        Me.lbl_desc_view_trans.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lbl_desc_view_trans.Visible = False
        '
        'lbl_desc_topup
        '
        Me.lbl_desc_topup.AutoSize = True
        Me.lbl_desc_topup.Font = New System.Drawing.Font("OCR A Extended", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_desc_topup.ForeColor = System.Drawing.Color.White
        Me.lbl_desc_topup.Location = New System.Drawing.Point(32, 58)
        Me.lbl_desc_topup.Name = "lbl_desc_topup"
        Me.lbl_desc_topup.Size = New System.Drawing.Size(168, 34)
        Me.lbl_desc_topup.TabIndex = 15
        Me.lbl_desc_topup.Text = "Topup Credits to" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Passengers"
        Me.lbl_desc_topup.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lbl_desc_topup.Visible = False
        '
        'lbl_default
        '
        Me.lbl_default.AutoSize = True
        Me.lbl_default.Font = New System.Drawing.Font("SimSun-ExtB", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_default.ForeColor = System.Drawing.Color.White
        Me.lbl_default.Location = New System.Drawing.Point(40, 65)
        Me.lbl_default.Name = "lbl_default"
        Me.lbl_default.Size = New System.Drawing.Size(153, 21)
        Me.lbl_default.TabIndex = 14
        Me.lbl_default.Text = "Select a Menu"
        Me.lbl_default.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DodgerBlue
        Me.ClientSize = New System.Drawing.Size(734, 357)
        Me.Controls.Add(Me.pnl_logout)
        Me.Controls.Add(Me.pnl_topup)
        Me.Controls.Add(Me.pnl_bus_payment_mode)
        Me.Controls.Add(Me.pnl_view_trans)
        Me.Controls.Add(Me.pnl_edit_remove_passenger)
        Me.Controls.Add(Me.pnl_add_passenger)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Main"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Bus Payment System"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnl_add_passenger.ResumeLayout(False)
        Me.pnl_add_passenger.PerformLayout()
        Me.pnl_edit_remove_passenger.ResumeLayout(False)
        Me.pnl_edit_remove_passenger.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnl_topup.ResumeLayout(False)
        Me.pnl_topup.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnl_logout.ResumeLayout(False)
        Me.pnl_logout.PerformLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnl_bus_payment_mode.ResumeLayout(False)
        Me.pnl_bus_payment_mode.PerformLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnl_view_trans.ResumeLayout(False)
        Me.pnl_view_trans.PerformLayout()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lbl_desc_edit_pass As System.Windows.Forms.Label
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents pnl_add_passenger As System.Windows.Forms.Panel
    Friend WithEvents pnl_edit_remove_passenger As System.Windows.Forms.Panel
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents pnl_topup As System.Windows.Forms.Panel
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents pnl_logout As System.Windows.Forms.Panel
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents pnl_bus_payment_mode As System.Windows.Forms.Panel
    Friend WithEvents PictureBox5 As System.Windows.Forms.PictureBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents pnl_view_trans As System.Windows.Forms.Panel
    Friend WithEvents PictureBox6 As System.Windows.Forms.PictureBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents status_admin_name As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel3 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel4 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents status_date As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel6 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel7 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents status_time As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents lbl_desc_add_pass As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents lbl_default As System.Windows.Forms.Label
    Friend WithEvents lbl_desc_topup As System.Windows.Forms.Label
    Friend WithEvents lbl_desc_view_trans As System.Windows.Forms.Label
    Friend WithEvents lbl_desc_bus_payment_mode As System.Windows.Forms.Label
    Friend WithEvents lbl_desc_logout As System.Windows.Forms.Label
End Class
