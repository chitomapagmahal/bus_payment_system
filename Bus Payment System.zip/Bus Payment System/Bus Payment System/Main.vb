﻿Public Class Main

    Private Sub MouseLeaveAll()

        pnl_add_passenger.BackColor = Color.White
        pnl_edit_remove_passenger.BackColor = Color.White
        pnl_topup.BackColor = Color.White
        pnl_view_trans.BackColor = Color.White
        pnl_bus_payment_mode.BackColor = Color.White
        pnl_logout.BackColor = Color.White

        lbl_desc_add_pass.Hide()
        lbl_desc_edit_pass.Hide()
        lbl_desc_topup.Hide()
        lbl_desc_view_trans.Hide()
        lbl_desc_bus_payment_mode.Hide()
        lbl_desc_logout.Hide()

        lbl_default.Show()

    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick

        status_date.Text = Date.Now.ToString("MM/dd/yyyy")
        status_time.Text = Date.Now.ToString("hh:mm:ss tt")

    End Sub

    Private Sub PictureBox1_MouseEnter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.MouseEnter, pnl_add_passenger.MouseEnter, Label6.MouseEnter

        pnl_add_passenger.BackColor = Color.Aqua
        lbl_desc_add_pass.Show()

        lbl_default.Hide()

    End Sub

    Private Sub pnl_add_passenger_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pnl_add_passenger.MouseLeave, PictureBox1.MouseLeave, Label6.MouseLeave

        Call MouseLeaveAll()

    End Sub

    Private Sub PictureBox2_MouseEnter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox2.MouseEnter, pnl_edit_remove_passenger.MouseEnter, Label7.MouseEnter

        pnl_edit_remove_passenger.BackColor = Color.Aqua
        lbl_desc_edit_pass.Show()

        lbl_default.Hide()

    End Sub

    Private Sub PictureBox2_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox2.MouseLeave, pnl_edit_remove_passenger.MouseLeave, Label7.MouseLeave

        Call MouseLeaveAll()

    End Sub

    Private Sub pnl_topup_MouseEnter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pnl_topup.MouseEnter, PictureBox3.MouseEnter, Label8.MouseEnter

        pnl_topup.BackColor = Color.Aqua
        lbl_desc_topup.Show()

        lbl_default.Hide()

    End Sub

    Private Sub pnl_topup_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pnl_topup.MouseLeave, PictureBox3.MouseLeave, Label8.MouseLeave

        Call MouseLeaveAll()

    End Sub

    Private Sub Main_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing

        DialogResult = MessageBox.Show("Are you sure?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If DialogResult = Windows.Forms.DialogResult.Yes Then

            Splash_Screen.Close()

        Else

            e.Cancel = True

        End If

    End Sub

    Private Sub pnl_view_trans_MouseEnter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pnl_view_trans.MouseEnter, PictureBox6.MouseEnter, Label11.MouseEnter

        pnl_view_trans.BackColor = Color.Aqua
        lbl_desc_view_trans.Show()

        lbl_default.Hide()

    End Sub

    Private Sub pnl_view_trans_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pnl_view_trans.MouseLeave, PictureBox6.MouseLeave, Label11.MouseLeave

        Call MouseLeaveAll()

    End Sub

    Private Sub PictureBox5_MouseEnter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pnl_bus_payment_mode.MouseEnter, PictureBox5.MouseEnter, Label10.MouseEnter

        pnl_bus_payment_mode.BackColor = Color.Aqua
        lbl_desc_bus_payment_mode.Show()

        lbl_default.Hide()

    End Sub

    Private Sub PictureBox5_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pnl_bus_payment_mode.MouseLeave, PictureBox5.MouseLeave, Label10.MouseLeave

        Call MouseLeaveAll()

    End Sub

    Private Sub pnl_logout_MouseEnter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pnl_logout.MouseEnter, PictureBox4.MouseEnter, Label9.MouseEnter

        pnl_logout.BackColor = Color.Aqua
        lbl_desc_logout.Show()

        lbl_default.Hide()

    End Sub

    Private Sub pnl_logout_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pnl_logout.MouseLeave, PictureBox4.MouseLeave, Label9.MouseLeave

        Call MouseLeaveAll()

    End Sub

    Private Sub pnl_logout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pnl_logout.Click, PictureBox4.Click, Label9.Click

        Me.Hide()

        MsgBox("You have been Logged Out.", MsgBoxStyle.Information, "Logout")

        Login.Show()

    End Sub

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pnl_add_passenger.Click, PictureBox1.Click, Label6.Click

        Me.Hide()

        Add_Passenger.Show()

    End Sub

    Private Sub PictureBox2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pnl_edit_remove_passenger.Click, PictureBox2.Click, Label7.Click

        Me.Hide()

        Update_Delete_Passenger.Show()

    End Sub

    Private Sub PictureBox3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pnl_topup.Click, PictureBox3.Click, Label8.Click

        Me.Hide()

        Topup.Show()

    End Sub

    Private Sub pnl_bus_payment_mode_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pnl_bus_payment_mode.Click, PictureBox5.Click, Label10.Click

        Me.Hide()

        Bus_Payment_Mode.Show()

    End Sub

    Private Sub PictureBox6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pnl_view_trans.Click, PictureBox6.Click, Label11.Click

        Me.Hide()

        View_Transactions.Show()

    End Sub
End Class