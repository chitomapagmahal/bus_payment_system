﻿Public Class Login

    Private Sub Login_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

        DialogResult = MessageBox.Show("Are you sure?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If DialogResult = Windows.Forms.DialogResult.Yes Then

            Splash_Screen.Close()

        Else

            e.Cancel = True

        End If

    End Sub

    Private Sub Login_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Call DATABASE_CONNECTION()

    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged

        If CheckBox1.Checked = True Then

            txt_password.UseSystemPasswordChar = False

        Else

            txt_password.UseSystemPasswordChar = True

        End If

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        txt_username.Clear()
        txt_password.Clear()

        CheckBox1.Checked = False

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        rs = New ADODB.Recordset
        rs.Open("SELECT * FROM `admin` WHERE `username` = '" & txt_username.Text & "' AND `password` = '" & txt_password.Text & "' LIMIT 1 ", cn, 1, 2)

        If Not rs.EOF Then

            Dim NAME As String = rs.Fields("name").Value
            plate_number = rs.Fields("plate_number").Value

            Main.status_admin_name.Text = NAME

            Me.Hide()

            MsgBox("Welcome " & NAME & ".", MsgBoxStyle.Information, "Login Successful")

            Main.Show()

        Else

            MsgBox("Invalid username or password!", MsgBoxStyle.Critical, "Login Failed")

        End If

    End Sub

    Private Sub txt_password_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txt_password.KeyDown

        If e.KeyCode = Keys.Enter Then

            Button1.PerformClick()

        End If

    End Sub
End Class