﻿Public Class Splash_Screen

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick

        ProgressBar1.Increment(1)

        If (ProgressBar1.Value = 100) Then

            Timer1.Stop()

            Me.Hide()

            Login.Show()

        End If

    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked

        Timer1.Stop()

        Me.Hide()

        Login.Show()

    End Sub

End Class
